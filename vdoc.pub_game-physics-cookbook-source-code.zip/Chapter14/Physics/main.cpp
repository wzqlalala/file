#include <iostream>
#include <cstdio>
#include "vectors.h"
#include "matrices.h"
#include <stdlib.h>
#include <limits>

int main(int argc, char** argv) {
	std::cout << "Press return to exit...";

	getchar();

	return 0;
}